package fr.billyrosty.cyberchat.api;

/**
 * Holds the running {@link CyberChatAPI}. CyberChat registers on enable and unregisters on
 * disable; everyone else only ever calls {@link #get()} or {@link #isAvailable()}.
 */
public final class CyberChatAPIProvider {

    private static CyberChatAPI instance;

    private CyberChatAPIProvider() {}

    /**
     * @throws IllegalStateException if CyberChat is not installed, or has not enabled yet. Call
     *         {@link #isAvailable()} first when CyberChat is a soft dependency.
     */
    public static CyberChatAPI get() {
        if (instance == null) {
            throw new IllegalStateException("CyberChat API is not loaded yet.");
        }
        return instance;
    }

    /** True once CyberChat has enabled and before it disables. Safe to call at any time. */
    public static boolean isAvailable() {
        return instance != null;
    }

    public static void register(CyberChatAPI api) {
        if (instance != null) {
            throw new IllegalStateException("CyberChat API is already registered.");
        }
        instance = api;
    }

    public static void unregister() {
        instance = null;
    }
}
