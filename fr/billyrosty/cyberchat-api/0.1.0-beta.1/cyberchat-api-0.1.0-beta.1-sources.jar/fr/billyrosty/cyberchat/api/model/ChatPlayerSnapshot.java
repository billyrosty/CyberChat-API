package fr.billyrosty.cyberchat.api.model;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * A player's chat state at the moment it was read. Detached from the live record: mutating the
 * player afterwards does not change the snapshot, and the snapshot cannot change the player.
 *
 * @param uuid          the account.
 * @param name          the last name seen for that account, not the nickname.
 * @param channelId     the channel their plain messages go to.
 * @param nickname      their nickname, or null when they have none.
 * @param messagesOpen  false when they have closed their private messages with {@code /msgtoggle}.
 * @param spy           whether they see everyone's private messages.
 * @param socialSpy     whether they see public chat regardless of channel range.
 * @param ignored       accounts they ignore.
 * @param mutes         every mute in force against them, global one included.
 */
public record ChatPlayerSnapshot(
        UUID uuid,
        String name,
        String channelId,
        String nickname,
        boolean messagesOpen,
        boolean spy,
        boolean socialSpy,
        Set<UUID> ignored,
        List<MuteSnapshot> mutes
) {

    public ChatPlayerSnapshot {
        ignored = Set.copyOf(ignored);
        mutes = List.copyOf(mutes);
    }

    /** True when a mute covers this channel -- either that channel's own, or a global one. */
    public boolean isMutedIn(String channelId) {
        return mutes.stream().anyMatch(mute ->
                mute.isGlobal() || mute.channelId().equalsIgnoreCase(channelId));
    }

    public boolean isGloballyMuted() {
        return mutes.stream().anyMatch(MuteSnapshot::isGlobal);
    }
}
