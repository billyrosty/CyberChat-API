package fr.billyrosty.cyberchat.api.event;

import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Fired on the sending node when a private message is about to go out, once the sender-side
 * checks have passed -- length, cooldown, newcomer restrictions.
 * <p>
 * When the target is on this server their {@code /msgtoggle} and ignore settings have been
 * checked too, and {@link #getTargetUuid()} is their account. When they are on another node only
 * their name is known here, {@link #getTargetUuid()} is <b>null</b>, and those two checks run
 * over there after this event -- so a listener can see a message that is then dropped on arrival.
 * <p>
 * Identities are accounts rather than {@code Player}s because either end may be elsewhere on the
 * network, or be the console -- {@link #isFromConsole()} says so.
 * <p>
 * Cancelling drops the message silently; tell the sender why yourself if that matters.
 * <b>Asynchronous.</b>
 */
public class CyberChatPrivateMessageEvent extends CyberChatEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final UUID senderUuid;
    private final String senderName;
    private final UUID targetUuid;
    private final String targetName;
    private String message;
    private boolean cancelled;

    public CyberChatPrivateMessageEvent(UUID senderUuid, String senderName,
                                        UUID targetUuid, String targetName, String message) {
        super(true);
        this.senderUuid = senderUuid;
        this.senderName = senderName;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
        this.message = message;
    }

    public UUID getSenderUuid() { return senderUuid; }
    public String getSenderName() { return senderName; }
    /** The target's account, or null when they are on another server and only the name is known. */
    public UUID getTargetUuid() { return targetUuid; }
    public String getTargetName() { return targetName; }

    /** The message body, already escaped. Rewriting it changes what the target receives. */
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    /** True when the console sent this, in which case the sender uuid is a fixed placeholder. */
    public boolean isFromConsole() {
        return senderUuid.equals(new UUID(0, 1));
    }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
