package fr.billyrosty.cyberchat.api.event;

import org.bukkit.event.Event;

/** Base class for every event CyberChat fires, so a listener can catch the family at once. */
public abstract class CyberChatEvent extends Event {

    protected CyberChatEvent() {
        super();
    }

    protected CyberChatEvent(boolean async) {
        super(async);
    }
}
