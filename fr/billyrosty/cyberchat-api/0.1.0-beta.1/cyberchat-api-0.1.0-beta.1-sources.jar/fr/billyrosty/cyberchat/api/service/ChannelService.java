package fr.billyrosty.cyberchat.api.service;

import fr.billyrosty.cyberchat.api.model.ChannelDefinition;
import fr.billyrosty.cyberchat.api.model.ChannelSnapshot;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.Optional;

/**
 * Channels: what exists, who is in which one, and how to add one of your own.
 *
 * <p>Every method is safe to call from the main thread. {@link #register} and {@link #unregister}
 * touch a concurrent map and are safe from anywhere; the rest read live plugin state and should
 * be called from the main thread unless noted.
 */
public interface ChannelService {

    /** Every channel, defined in {@code channels.yml} or registered through {@link #register}. */
    Collection<ChannelSnapshot> list();

    /** Look up by id or alias, case-insensitively. */
    Optional<ChannelSnapshot> get(String idOrAlias);

    /** The id of the channel a player's plain messages currently go to. */
    String activeChannel(Player player);

    /**
     * Move a player to a channel, as {@code /channel} would -- the change is persisted and, on a
     * network, visible to the other servers.
     *
     * <p>Fires {@code CyberChatChannelSwitchEvent}, which a listener may cancel.
     *
     * @return false if no channel matches that id or alias, if a listener cancelled the switch,
     *         or if the player has no loaded record on this node. Permissions are <b>not</b>
     *         checked: the caller decides whether this player is allowed there.
     */
    boolean setActiveChannel(Player player, String idOrAlias);

    /**
     * Adds a channel that exists in memory only -- not written to {@code channels.yml}, gone on
     * restart unless registered again on every enable. A registered channel shadows a
     * config-defined one with the same id for as long as it stays registered.
     *
     * @throws IllegalArgumentException if the definition's quick prefix is already taken.
     */
    void register(ChannelDefinition definition);

    /** Removes a channel added by {@link #register}. Config-defined channels are unaffected. */
    void unregister(String id);

    /**
     * Sends a message to a channel as if the plugin itself had spoken -- it goes through the
     * channel's own audience and cross-server rules, but skips the moderation pipeline. Player
     * text must never be passed here unescaped.
     *
     * @param message a MiniMessage string, which may contain {@code {cc:...}} tokens.
     */
    void broadcast(String channelId, String message);
}
