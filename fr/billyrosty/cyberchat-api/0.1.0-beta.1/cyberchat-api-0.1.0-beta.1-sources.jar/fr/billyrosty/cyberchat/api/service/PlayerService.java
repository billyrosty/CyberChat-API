package fr.billyrosty.cyberchat.api.service;

import fr.billyrosty.cyberchat.api.model.ChatPlayerSnapshot;
import fr.billyrosty.cyberchat.api.model.MuteSnapshot;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * A player's chat state: their channel, their mutes, their toggles, who they ignore.
 *
 * <p>The synchronous methods read the in-memory record of a player connected to <b>this</b> node
 * and are main-thread only. {@link #loadSnapshot} exists for everyone else -- an offline player,
 * or one connected to another server of the network -- and goes to storage, so it returns a
 * future and must not be waited on from the main thread.
 */
public interface PlayerService {

    /** State of a player connected to this server. Empty if they are not loaded here. */
    Optional<ChatPlayerSnapshot> snapshot(Player player);

    /** Same, by account. Empty when that account is not connected to this node. */
    Optional<ChatPlayerSnapshot> snapshot(UUID uuid);

    /**
     * Reads a player's state from storage, whether or not they are online and whichever server
     * they are on. Empty when the account has no row yet -- someone who has never joined.
     *
     * <p>Never call {@code join()} on this from the main thread.
     */
    CompletableFuture<Optional<ChatPlayerSnapshot>> loadSnapshot(UUID uuid);

    /** Mutes in force against a player on this node, global one included. */
    List<MuteSnapshot> mutes(UUID uuid);

    /**
     * Whether a player may currently speak in a channel: false when a mute covers that channel
     * or every channel. Cheaper than reading {@link #mutes} and checking it yourself, and it
     * clears expired mutes on the way.
     */
    boolean isMuted(UUID uuid, String channelId);

    /** Whether a player has closed their private messages with {@code /msgtoggle}. */
    boolean acceptsPrivateMessages(UUID uuid);

    /** Whether {@code ignorer} is ignoring {@code target}. */
    boolean isIgnoring(UUID ignorer, UUID target);

    /** The nickname in use, or empty when the player goes by their account name. */
    Optional<String> nickname(UUID uuid);

    /**
     * Resolves a name -- an account name or a nickname -- to the account behind it, the same way
     * {@code /msg} does, partial names included. Empty when nothing matches, or when several do.
     *
     * <p>Only players <b>online on this server</b> are considered. An offline account, or one
     * connected to another node of the network, will not resolve here.
     */
    Optional<UUID> resolve(String nameOrNickname);
}
