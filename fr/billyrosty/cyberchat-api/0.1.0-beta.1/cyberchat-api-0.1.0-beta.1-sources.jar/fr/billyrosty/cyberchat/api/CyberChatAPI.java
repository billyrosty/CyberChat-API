package fr.billyrosty.cyberchat.api;

import fr.billyrosty.cyberchat.api.service.ChannelService;
import fr.billyrosty.cyberchat.api.service.PlayerService;
import org.bukkit.plugin.Plugin;

/**
 * Entry point to everything CyberChat exposes to other plugins.
 *
 * <pre>{@code
 * CyberChatAPI api = CyberChatAPI.getInstance();
 * api.getChannelService().register(ChannelDefinition.builder("trade").build());
 * }</pre>
 *
 * The instance exists from the moment CyberChat enables until it disables. A plugin that reads it
 * in its own {@code onEnable} must declare {@code depend: [CyberChat]} in its {@code plugin.yml},
 * or use {@code softdepend} and guard with {@link CyberChatAPIProvider#isAvailable()}.
 *
 * <p><b>This surface is pre-1.0 and will change.</b> Until CyberChat reaches a stable release,
 * signatures here may be added to, renamed or removed between versions without a deprecation
 * period. Pin an exact version rather than a range.
 */
public interface CyberChatAPI {

    /** Channels: list, look up, register one that lives only in memory, move a player between them. */
    ChannelService getChannelService();

    /** A player's own chat state -- active channel, mutes, private-message toggle, spy, ignores. */
    PlayerService getPlayerService();

    /** The running CyberChat version, as built from the git tag (e.g. {@code "0.1.0-beta.1"}). */
    String getVersion();

    /**
     * Whether this node is part of a Redis-backed network. False on a standalone server, where
     * every channel is effectively local whatever its {@code cross-server} setting says.
     */
    boolean isMultiServer();

    /** The CyberChat plugin instance, for scheduling and event registration. */
    Plugin getPlugin();

    static CyberChatAPI getInstance() {
        return CyberChatAPIProvider.get();
    }
}
