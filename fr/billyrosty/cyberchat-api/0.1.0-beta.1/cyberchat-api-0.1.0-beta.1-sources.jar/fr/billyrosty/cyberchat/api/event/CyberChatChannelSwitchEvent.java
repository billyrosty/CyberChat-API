package fr.billyrosty.cyberchat.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player changes the channel their plain messages go to -- through
 * {@code /channel}, or through {@code ChannelService.setActiveChannel}. Permission checks have
 * already passed by then.
 * <p>
 * Cancelling leaves the player in {@link #getFrom()}. This does <b>not</b> fire for a quick-prefix
 * message ({@code !hello}), which routes one line without switching anything.
 * <p>
 * Fired on the main thread.
 */
public class CyberChatChannelSwitchEvent extends CyberChatEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final String from;
    private final String to;
    private boolean cancelled;

    public CyberChatChannelSwitchEvent(Player player, String from, String to) {
        this.player = player;
        this.from = from;
        this.to = to;
    }

    public Player getPlayer() { return player; }

    /** The channel id they are leaving. */
    public String getFrom() { return from; }

    /** The channel id they are moving to. */
    public String getTo() { return to; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
