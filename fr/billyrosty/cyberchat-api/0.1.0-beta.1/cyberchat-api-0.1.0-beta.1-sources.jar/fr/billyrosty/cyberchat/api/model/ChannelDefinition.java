package fr.billyrosty.cyberchat.api.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A channel another plugin wants CyberChat to serve. Built here, handed to
 * {@code ChannelService.register}, and from that point indistinguishable from one written in
 * {@code channels.yml} -- same audience rules, same cross-server behaviour, visible to
 * {@code /channel} and to every stage of the pipeline.
 *
 * <p>Registered channels live in memory only. They are gone on restart, and gone after a
 * {@code /cyberchat reload} does not bring them back on its own -- register again from your
 * {@code onEnable}.
 *
 * <pre>{@code
 * ChannelDefinition trade = ChannelDefinition.builder("trade")
 *         .alias("tr")
 *         .speakPermission("myplugin.trade")
 *         .cooldownSeconds(5)
 *         .crossServer(true)
 *         .build();
 * }</pre>
 */
public final class ChannelDefinition {

    private final String id;
    private final List<String> aliases;
    private final String quickPrefix;
    private final String speakPermission;
    private final String readPermission;
    private final String formatId;
    private final String color;
    private final int cooldownSeconds;
    private final boolean crossServer;
    private final int radius;
    private final boolean sameWorldOnly;
    private final boolean relayToDiscord;

    private ChannelDefinition(Builder b) {
        this.id = b.id;
        this.aliases = List.copyOf(b.aliases);
        this.quickPrefix = b.quickPrefix;
        this.speakPermission = b.speakPermission;
        this.readPermission = b.readPermission;
        this.formatId = b.formatId;
        this.color = b.color;
        this.cooldownSeconds = b.cooldownSeconds;
        // A radius, or a world restriction, cannot survive a hop between servers. Forcing it here
        // rather than at registration means the definition never claims something it cannot do.
        this.crossServer = b.crossServer && b.radius < 0 && !b.sameWorldOnly;
        this.radius = b.radius;
        this.sameWorldOnly = b.sameWorldOnly;
        this.relayToDiscord = b.relayToDiscord;
    }

    public static Builder builder(String id) {
        return new Builder(id);
    }

    public String id() { return id; }
    public List<String> aliases() { return aliases; }
    public String quickPrefix() { return quickPrefix; }
    public String speakPermission() { return speakPermission; }
    public String readPermission() { return readPermission; }
    public String formatId() { return formatId; }
    public String color() { return color; }
    public int cooldownSeconds() { return cooldownSeconds; }
    public boolean crossServer() { return crossServer; }
    public int radius() { return radius; }
    public boolean sameWorldOnly() { return sameWorldOnly; }
    public boolean relayToDiscord() { return relayToDiscord; }

    public static final class Builder {

        private final String id;
        private final List<String> aliases = new ArrayList<>();
        private String quickPrefix = "";
        private String speakPermission = "";
        private String readPermission = "";
        private String formatId = "";
        private String color = "";
        private int cooldownSeconds = 0;
        private boolean crossServer = false;
        private int radius = -1;
        private boolean sameWorldOnly = false;
        private boolean relayToDiscord = false;

        private Builder(String id) {
            Objects.requireNonNull(id, "id");
            if (id.isBlank()) {
                throw new IllegalArgumentException("A channel id cannot be blank.");
            }
            this.id = id.toLowerCase();
        }

        /** An alternative name accepted by {@code /channel}. Call more than once for several. */
        public Builder alias(String alias) {
            aliases.add(alias.toLowerCase());
            return this;
        }

        /**
         * A character that sends a single message to this channel without switching to it.
         * Registration fails if another channel already claims it.
         */
        public Builder quickPrefix(String quickPrefix) {
            this.quickPrefix = quickPrefix;
            return this;
        }

        /** Permission required to send. Empty (the default) means everyone can. */
        public Builder speakPermission(String permission) {
            this.speakPermission = permission;
            return this;
        }

        /** Permission required to read. Empty (the default) means everyone can. */
        public Builder readPermission(String permission) {
            this.readPermission = permission;
            return this;
        }

        /** Which entry of {@code formats.yml} renders this channel. Empty for the usual selection. */
        public Builder formatId(String formatId) {
            this.formatId = formatId;
            return this;
        }

        /** A MiniMessage tag wrapped around the chosen format, e.g. {@code "<green>"}. */
        public Builder color(String color) {
            this.color = color;
            return this;
        }

        public Builder cooldownSeconds(int seconds) {
            this.cooldownSeconds = Math.max(0, seconds);
            return this;
        }

        /** Ignored when a radius or a world restriction is set -- see {@link #radius}. */
        public Builder crossServer(boolean crossServer) {
            this.crossServer = crossServer;
            return this;
        }

        /** Range in blocks a listener must be within. -1, the default, is server-wide. */
        public Builder radius(int radius) {
            this.radius = radius;
            return this;
        }

        public Builder sameWorldOnly(boolean sameWorldOnly) {
            this.sameWorldOnly = sameWorldOnly;
            return this;
        }

        public Builder relayToDiscord(boolean relayToDiscord) {
            this.relayToDiscord = relayToDiscord;
            return this;
        }

        public ChannelDefinition build() {
            return new ChannelDefinition(this);
        }
    }
}
