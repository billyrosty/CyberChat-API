package fr.billyrosty.cyberchat.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired for a chat message right before it leaves the pipeline -- after CyberChat's own
 * mute/filter/anti-spam checks already ran, so a listener sees exactly what CyberChat itself
 * decided was fine to send. Cancelling here stops it from ever being dispatched, same as
 * cancelling any other Bukkit event.
 * <p>
 * {@link #getMessage()} is the fully-formatted line -- the format template with the player's text
 * already spliced in, {@code {cc:...}} tokens and all (they resolve later, per recipient; a
 * listener sees the template, not the rendered text any one viewer would get). Changing it with
 * {@link #setMessage(String)} changes what every recipient, and every server of the network, sees.
 * <p>
 * <b>Asynchronous</b>, same as Paper's {@code AsyncChatEvent} -- the chat pipeline fires it off
 * the main thread. A listener must not touch other Bukkit API directly; hop back to the main
 * thread first, exactly as for any other async chat event.
 */
public class CyberChatMessageEvent extends CyberChatEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player sender;
    private final String channelId;
    private String message;
    private boolean cancelled;

    public CyberChatMessageEvent(Player sender, String channelId, String message) {
        super(true);
        this.sender = sender;
        this.channelId = channelId;
        this.message = message;
    }

    public Player getSender() { return sender; }
    public String getChannelId() { return channelId; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
