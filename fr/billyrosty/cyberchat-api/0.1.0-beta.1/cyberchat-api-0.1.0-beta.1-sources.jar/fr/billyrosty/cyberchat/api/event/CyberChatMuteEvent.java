package fr.billyrosty.cyberchat.api.event;

import fr.billyrosty.cyberchat.api.model.MuteSnapshot;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Fired after a mute is issued or lifted, on the node that issued it -- not on the other servers,
 * which only refresh their own copy. Informational: the change is already written to storage by
 * the time this reaches a listener, so there is nothing to cancel.
 * <p>
 * The target may be offline, and may never have joined this server, so there is no {@code Player}
 * here. Fired on the main thread.
 */
public class CyberChatMuteEvent extends CyberChatEvent {

    private static final HandlerList HANDLERS = new HandlerList();

    /** Whether the mute was issued or lifted. */
    public enum Action { MUTED, UNMUTED }

    private final Action action;
    private final UUID targetUuid;
    private final String targetName;
    private final String actorName;
    private final MuteSnapshot mute;

    public CyberChatMuteEvent(Action action, UUID targetUuid, String targetName,
                              String actorName, MuteSnapshot mute) {
        this.action = action;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
        this.actorName = actorName;
        this.mute = mute;
    }

    public Action getAction() { return action; }
    public UUID getTargetUuid() { return targetUuid; }
    public String getTargetName() { return targetName; }

    /** Who issued it -- a player's name, or {@code "CONSOLE"}. */
    public String getActorName() { return actorName; }

    /**
     * The mute that was issued. On {@link Action#UNMUTED} this describes what was lifted, and its
     * {@code until} is the expiry the mute had before it was removed.
     */
    public MuteSnapshot getMute() { return mute; }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
