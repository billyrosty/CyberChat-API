package fr.billyrosty.cyberchat.api.model;

import java.util.List;

/**
 * A channel as it is configured right now. Read-only and detached: a snapshot taken before a
 * {@code /cyberchat reload} keeps the old values, it does not track the live definition.
 *
 * @param id             the channel's id, lowercase, unique.
 * @param aliases        alternative names accepted by {@code /channel}.
 * @param quickPrefix    a character that routes one message to this channel without switching to
 *                       it ({@code "!"} for staff by default). Empty when the channel has none.
 * @param speakPermission permission required to send to the channel. Empty means everyone.
 * @param readPermission permission required to see the channel. Empty means everyone.
 * @param cooldownSeconds seconds a player must wait between two messages. 0 for no cooldown.
 * @param crossServer    whether the channel reaches the rest of the network. Always false when
 *                       {@code radius} is set or {@code sameWorldOnly} is on -- distance and
 *                       worlds mean nothing between two servers.
 * @param radius         -1 for server-wide, otherwise the range in blocks a listener must be in.
 * @param sameWorldOnly  restrict the audience to the sender's world.
 * @param relayToDiscord whether messages in this channel are relayed to Discord.
 */
public record ChannelSnapshot(
        String id,
        List<String> aliases,
        String quickPrefix,
        String speakPermission,
        String readPermission,
        int cooldownSeconds,
        boolean crossServer,
        int radius,
        boolean sameWorldOnly,
        boolean relayToDiscord
) {

    public ChannelSnapshot {
        aliases = List.copyOf(aliases);
    }

    /** True when the channel never leaves the server it was sent from. */
    public boolean isLocal() {
        return !crossServer;
    }
}
