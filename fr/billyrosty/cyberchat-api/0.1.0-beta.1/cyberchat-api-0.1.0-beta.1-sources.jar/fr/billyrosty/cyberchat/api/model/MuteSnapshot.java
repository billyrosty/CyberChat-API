package fr.billyrosty.cyberchat.api.model;

/**
 * One mute in force against a player, in one channel.
 *
 * @param channelId the muted channel, or {@link #GLOBAL} for a mute that covers every channel.
 * @param until     epoch millis when the mute expires, or {@link #PERMANENT}.
 * @param reason    the reason given, empty if none was.
 * @param by        the name of whoever issued it ({@code "CONSOLE"} when it came from the console).
 */
public record MuteSnapshot(String channelId, long until, String reason, String by) {

    /** The channel id standing for "every channel". */
    public static final String GLOBAL = "*";

    /** The value of {@link #until} for a mute that never expires. */
    public static final long PERMANENT = -1;

    public boolean isPermanent() {
        return until == PERMANENT;
    }

    public boolean isGlobal() {
        return GLOBAL.equals(channelId);
    }

    /** Milliseconds left, or {@link Long#MAX_VALUE} when permanent. Never negative. */
    public long remainingMillis() {
        if (isPermanent()) return Long.MAX_VALUE;
        return Math.max(0, until - System.currentTimeMillis());
    }
}
